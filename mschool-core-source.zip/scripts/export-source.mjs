import {readFile,writeFile} from 'node:fs/promises';
const mapping={'migration.sql':'supabase/migrations/202610160001_core.sql','route.ts':'app/api/agents/router/route.ts','prompts.ts':'lib/prompts.ts'};
const sources={};for(const [key,path] of Object.entries(mapping))sources[key]=await readFile(path,'utf8');
await writeFile('lib/source-preview.json',JSON.stringify(sources));
