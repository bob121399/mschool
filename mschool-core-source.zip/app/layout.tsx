import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'MSchool · Platform Core',description:'Архитектура корпоративного обучения MSchool. Итерация 01.'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="ru"><body>{children}</body></html>;}
