import { generateText, Output } from 'ai';
import { createOpenAI } from '@ai-sdk/openai';
import { requestSchema, courseOutputSchema, assessmentOutputSchema, answerSchema, analyticsSchema, rubricSchema } from '@/lib/contracts';
import { config, userDb, auditDb } from '@/lib/db';
import { systemPrompt } from '@/lib/prompts';
import type { CourseRow, Json } from '@/lib/database.types';
export const dynamic = 'force-dynamic';
const headers = {'Cache-Control':'no-store','Content-Type':'application/json'};
class HttpError extends Error {constructor(readonly status:number,readonly code:string){super(code);}}
function assertDb(error:{message:string}|null):void {if(error) throw new HttpError(503,'DATABASE_ERROR');}
async function boundedJson(request:Request):Promise<unknown> {
 const reader=request.body?.getReader(); if(!reader) throw new HttpError(400,'EMPTY_BODY');
 const chunks:Uint8Array[]=[];let size=0;
 try {while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>20000){await reader.cancel();throw new HttpError(413,'BODY_TOO_LARGE');}chunks.push(value);}} finally {reader.releaseLock();}
 const merged=new Uint8Array(size);let offset=0;for(const chunk of chunks){merged.set(chunk,offset);offset+=chunk.length;}
 try{return JSON.parse(new TextDecoder().decode(merged)) as unknown;}catch{throw new HttpError(400,'INVALID_JSON');}
}
export async function POST(request:Request):Promise<Response> {
 const requestId=crypto.randomUUID();let runId:string|undefined;
 const c=config();if(!c)return Response.json({error:'INTEGRATIONS_NOT_CONFIGURED',requestId},{status:503,headers});
 const admin=auditDb(c);
 try {
  if(!request.headers.get('content-type')?.startsWith('application/json'))throw new HttpError(415,'JSON_REQUIRED');
  const token=request.headers.get('authorization')?.match(/^Bearer ([^\s]+)$/i)?.[1];
  if(!token)throw new HttpError(401,'UNAUTHENTICATED');
  const db=userDb(c,token);
  const {data:auth,error:authError}=await db.auth.getUser(token);
  if(authError||!auth.user)throw new HttpError(401,'UNAUTHENTICATED');
  const {data:actor,error:actorError}=await db.from('users').select('*').eq('id',auth.user.id).single();
  if(actorError||!actor?.active)throw new HttpError(403,'MEMBERSHIP_REQUIRED');
  const parsed=requestSchema.safeParse(await boundedJson(request));
  if(!parsed.success)throw new HttpError(400,'INVALID_REQUEST');
  const task=parsed.data; // Deterministic routing: the model never selects its own permissions.
  const {data:agent,error:agentError}=await db.from('agents').select('*').eq('key',task.task).single();
  if(agentError||!agent||!agent.enabled||!agent.allowed_roles.includes(actor.role))throw new HttpError(403,'AGENT_FORBIDDEN');
  if(agent.scope==='tenant'&&!actor.tenant_id)throw new HttpError(403,'TENANT_REQUIRED');
  let course:CourseRow|undefined;let evidence:Json={};let sourceIds:string[]=[];
  if('courseId' in task){
   const {data,error}=await db.from('courses').select('*').eq('id',task.courseId).eq('tenant_id',actor.tenant_id ?? '').single();
   if(error||!data)throw new HttpError(404,'COURSE_NOT_FOUND');course=data;
   if(task.task==='methodist' && course.grade!==task.grade)throw new HttpError(409,'GRADE_MISMATCH');
   if(task.task==='assessor'){
    const rubric=rubricSchema.safeParse(course.rubric);
    if(!rubric.success)throw new HttpError(409,'VALID_RUBRIC_REQUIRED');
    const {data:enrollment,error:e}=await db.from('progress').select('id').eq('user_id',actor.id).eq('course_id',course.id).single();
    if(e||!enrollment)throw new HttpError(403,'ENROLLMENT_REQUIRED');
    evidence={rubric:rubric.data,course:course.content};
   }else{
    const result=task.task==='tutor'
     ? await db.rpc('search_chunks',{p_course:course.id,p_query:task.message})
     : await db.from('document_chunks').select('id,source_name,body').eq('tenant_id',actor.tenant_id ?? '').eq('course_id',course.id).order('id').limit(21);
    assertDb(result.error);const chunks=result.data ?? [];
    if(!chunks.length)throw new HttpError(422,'NO_RELEVANT_SOURCES');
    if(chunks.length>20)throw new HttpError(422,'SOURCE_BATCH_TOO_LARGE');
    sourceIds=chunks.map(x=>x.id);evidence=chunks;
   }
  } else if(task.task==='hr_analyst'){
   // RLS applies department scoping before rows ever reach the AI provider.
   const {data,error}=await db.from('progress').select('user_id,course_id,completion,passed,updated_at').eq('tenant_id',actor.tenant_id ?? '').order('id').limit(1001);
   assertDb(error);if((data?.length ?? 0)>1000)throw new HttpError(422,'ANALYTICS_BATCH_TOO_LARGE');
   evidence=data ?? [];
  } else if(task.task==='product_analyst'){
   const {data,error}=await db.rpc('product_metrics',{});assertDb(error);evidence=data;
  }
  if(JSON.stringify(evidence).length>60000)throw new HttpError(422,'CONTEXT_TOO_LARGE');
  const {data:run,error:runError}=await admin.rpc('begin_agent_run',{p_actor:actor.id,p_agent:task.task,p_model:c.model});
  if(runError)throw new HttpError(runError.code==='P0001'?429:503,runError.code==='P0001'?'RATE_LIMITED':'RUN_NOT_STARTED');
  if(!run)throw new HttpError(503,'RUN_NOT_STARTED');runId=run;
  const model=createOpenAI({apiKey:c.aiKey})(c.model);
  const options={model,system:systemPrompt(task.task,course?.grade),prompt:JSON.stringify({evidence,userRequest:task.message}),maxOutputTokens:6000,maxRetries:1,abortSignal:AbortSignal.any([request.signal,AbortSignal.timeout(60000)])};
  let output:Json;let outputTokens:number|undefined;
  if(task.task==='methodist'){
   const result=await generateText({...options,output:Output.object({schema:courseOutputSchema})});
   const draft=result.output;
   if(draft.modules.some(m=>m.lessons.some(l=>l.sourceIds.some(id=>!sourceIds.includes(id)))))throw new HttpError(502,'INVALID_CITATIONS');
   const {data,error}=await db.rpc('save_generated_course',{p_source:task.courseId,p_title:draft.title,p_content:draft});
   assertDb(error);if(!data)throw new HttpError(503,'DRAFT_NOT_SAVED');
   output=data;outputTokens=result.usage.outputTokens;
  } else if(task.task==='assessor' && course){
   const rubric=rubricSchema.parse(course.rubric);
   const result=await generateText({...options,output:Output.object({schema:assessmentOutputSchema})});
   const scores=result.output.scores;
   if(scores.length!==rubric.criteria.length || new Set(scores.map(s=>s.criterion)).size!==scores.length || rubric.criteria.some(r=>{const s=scores.find(x=>x.criterion===r.criterion);return !s||s.score>r.max_score;}))throw new HttpError(502,'INVALID_ASSESSMENT');
   const score=Math.round(scores.reduce((sum,s)=>sum+s.score,0)*100)/100;
   // Grade eligibility is deterministic; changing courses still requires an explicit assignment.
   const {data,error}=await admin.rpc('apply_assessment',{p_actor:actor.id,p_course:course.id,p_score:score,p_rubric:course.rubric,p_feedback:scores.map(s=>`${s.criterion}: ${s.feedback}`).join('\n')});
   assertDb(error);output=data;outputTokens=result.usage.outputTokens;
  } else if(task.task==='hr_analyst'||task.task==='product_analyst'){
   const result=await generateText({...options,output:Output.object({schema:analyticsSchema})});output=result.output;outputTokens=result.usage.outputTokens;
  }else{
   const result=await generateText({...options,output:Output.object({schema:answerSchema})});
   if(result.output.sourceIds.some(id=>!sourceIds.includes(id)))throw new HttpError(502,'INVALID_CITATIONS');
   if(task.task==='tutor'&&!result.output.needsHuman&&!result.output.sourceIds.length)throw new HttpError(502,'CITATIONS_REQUIRED');
   output=result.output;outputTokens=result.usage.outputTokens;
  }
  const {error:finishError}=await admin.from('agent_logs').update({status:'succeeded',finished_at:new Date().toISOString(),output_tokens:outputTokens ?? null}).eq('id',runId).eq('actor_id',actor.id);
  assertDb(finishError);
  return Response.json({requestId,runId,agent:task.task,result:output},{headers});
 }catch(error:unknown){
  const status=error instanceof HttpError?error.status:502;const code=error instanceof HttpError?error.code:'AGENT_EXECUTION_FAILED';
  if(runId){const {error:auditError}=await admin.from('agent_logs').update({status:'failed',finished_at:new Date().toISOString(),error_code:code}).eq('id',runId);if(auditError)console.error('audit_failure',{requestId,runId});}
  // No raw prompts, employee answers, tokens or provider messages in application logs.
  return Response.json({error:code,requestId,runId},{status,headers:{...headers,...(status===429?{'Retry-After':'60'}:{})}});
 }
}
