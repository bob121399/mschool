import { z } from 'zod';
export const roleSchema = z.enum(['SuperAdmin','HR','Manager','Employee']);
export const gradeSchema = z.enum(['Junior','Middle','Senior','Head of Department']);
export const agentSchema = z.enum(['sales','support','product_analyst','methodist','tutor','assessor','hr_analyst']);
export type Role = z.infer<typeof roleSchema>;
export type Grade = z.infer<typeof gradeSchema>;
export type AgentKey = z.infer<typeof agentSchema>;
const message = z.string().trim().min(1).max(8000);
const courseId = z.string().uuid();
export const requestSchema = z.discriminatedUnion('task', [
 z.object({task:z.literal('methodist'),courseId,message,grade:gradeSchema}).strict(),
 z.object({task:z.literal('tutor'),courseId,message}).strict(),
 z.object({task:z.literal('assessor'),courseId,message}).strict(),
 z.object({task:z.literal('hr_analyst'),message}).strict(),
 z.object({task:z.literal('product_analyst'),message}).strict(),
 z.object({task:z.literal('sales'),message}).strict(),
 z.object({task:z.literal('support'),message}).strict(),
]);
export type AgentRequest = z.infer<typeof requestSchema>;
export const rubricSchema = z.object({pass_score:z.number().min(0).max(100),criteria:z.array(z.object({criterion:z.string().min(1),max_score:z.number().positive().max(100)})).min(1).max(20)}).refine(r=>r.criteria.reduce((s,c)=>s+c.max_score,0)===100,'Rubric total must equal 100');
export const courseOutputSchema = z.object({title:z.string().min(1).max(200),modules:z.array(z.object({title:z.string(),lessons:z.array(z.object({title:z.string(),text:z.string(),sourceIds:z.array(z.string().uuid()).min(1)})).min(1).max(8),quiz:z.array(z.object({question:z.string(),options:z.array(z.string()).length(4),correctIndex:z.number().int().min(0).max(3)})).min(1).max(5)})).min(1).max(10)});
export const assessmentOutputSchema = z.object({scores:z.array(z.object({criterion:z.string(),score:z.number().min(0).max(100),feedback:z.string().max(2000)})).min(1).max(20)});
export const answerSchema = z.object({answer:z.string(),sourceIds:z.array(z.string().uuid()),needsHuman:z.boolean()});
export const analyticsSchema = z.object({summary:z.string(),findings:z.array(z.object({observation:z.string(),recommendation:z.string()})),limitations:z.array(z.string())});
