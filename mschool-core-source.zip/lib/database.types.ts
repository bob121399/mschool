import type { Role,Grade,AgentKey } from './contracts';
export type Json = string | number | boolean | null | { [key:string]: Json | undefined } | Json[];
type Table<R,I=Partial<R>> = {Row:R;Insert:I;Update:Partial<R>;Relationships:[]};
export type UserRow = {id:string;tenant_id:string|null;role:Role;department_id:string|null;display_name:string;active:boolean;created_at:string};
export type CourseRow = {id:string;tenant_id:string;title:string;grade:Grade;status:'draft'|'published'|'archived';content:Json;rubric:Json;created_by:string;created_at:string};
export type ProgressRow = {id:string;tenant_id:string;course_id:string;user_id:string;completion:number;passed:boolean;score:number|null;feedback:string|null;eligible_next_grade:Grade|null;updated_at:string};
export type ChunkRow = {id:string;tenant_id:string;course_id:string;source_name:string;body:string;search:unknown};
export interface Database {
 public: {
 Tables: {
 tenants:Table<{id:string;name:string;active:boolean;created_at:string}>;
 departments:Table<{id:string;tenant_id:string;name:string}>;
 users:Table<UserRow>;
 agents:Table<{key:AgentKey;scope:'platform'|'tenant';allowed_roles:Role[];enabled:boolean;prompt_version:string}>;
 courses:Table<CourseRow,Pick<CourseRow,'tenant_id'|'title'|'grade'|'created_by'> & Partial<CourseRow>>;
 progress:Table<ProgressRow>;
 document_chunks:Table<ChunkRow>;
 agent_logs:Table<{id:string;tenant_id:string|null;actor_id:string;agent:AgentKey;status:'running'|'succeeded'|'failed';prompt_version:string;model:string;output_tokens:number|null;error_code:string|null;created_at:string;finished_at:string|null}>;
 };
 Views:Record<string,never>;
 Functions:{
 save_generated_course:{Args:{p_source:string;p_title:string;p_content:Json};Returns:Json};
 search_chunks:{Args:{p_course:string;p_query:string};Returns:Pick<ChunkRow,'id'|'body'|'source_name'>[]};
 product_metrics:{Args:Record<string,never>;Returns:Json};
 begin_agent_run:{Args:{p_actor:string;p_agent:AgentKey;p_model:string};Returns:string};
 apply_assessment:{Args:{p_actor:string;p_course:string;p_score:number;p_feedback:string;p_rubric:Json};Returns:Json};
 };
 Enums:{app_role:Role;grade:Grade;agent_key:AgentKey};
 CompositeTypes:Record<string,never>;
 };
}
