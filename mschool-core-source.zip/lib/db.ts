import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';
export function config() {
 const url=process.env.SUPABASE_URL;
 const publicKey=process.env.SUPABASE_PUBLISHABLE_KEY;
 const secret=process.env.SUPABASE_SERVICE_ROLE_KEY;
 const aiKey=process.env.OPENAI_API_KEY;
 if (!url || !publicKey || !secret || !aiKey) return null;
 return {url,publicKey,secret,aiKey,model:process.env.OPENAI_MODEL ?? 'gpt-4.1-mini'};
}
export function userDb(c:NonNullable<ReturnType<typeof config>>,token:string) {
 return createClient<Database>(c.url,c.publicKey,{global:{headers:{Authorization:`Bearer ${token}`}},auth:{persistSession:false,autoRefreshToken:false}});
}
export function auditDb(c:NonNullable<ReturnType<typeof config>>) {
 // Service key is confined to server-only audit/quota and deterministic assessment RPCs.
 return createClient<Database>(c.url,c.secret,{auth:{persistSession:false,autoRefreshToken:false}});
}
