import { PGlite } from '@electric-sql/pglite';
import { readFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const db=new PGlite();let checks=0;
await db.exec(`create role anon;create role authenticated;create role service_role bypassrls;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$; grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`);
await db.exec(await readFile('supabase/migrations/202610160001_core.sql','utf8'));
const id=n=>`00000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
await db.exec(`insert into tenants(id,name) values('${id(1)}','A'),('${id(2)}','B');insert into departments(id,tenant_id,name) values('${id(11)}','${id(1)}','A1'),('${id(12)}','${id(1)}','A2'),('${id(21)}','${id(2)}','B1');`);
for(const [n,t,role,d] of [[101,1,'HR',null],[102,1,'Employee',11],[103,1,'Manager',11],[104,1,'Employee',12],[201,2,'HR',null],[202,2,'Employee',21],[999,null,'SuperAdmin',null]]){
 await db.query('insert into auth.users values($1)',[id(n)]);
 await db.query('insert into users(id,tenant_id,role,department_id,display_name) values($1,$2,$3,$4,$5)',[id(n),t?id(t):null,role,d?id(d):null,`User ${n}`]);
}
for(const [n,t,u] of [[301,1,101],[302,2,201]])await db.query(`insert into courses(id,tenant_id,title,grade,status,created_by,rubric) values($1,$2,'Course','Junior','published',$3,'{"pass_score":70,"criteria":[{"criterion":"Accuracy","max_score":100}]}')`,[id(n),id(t),id(u)]);
for(const [u,t,c] of [[102,1,301],[104,1,301],[202,2,302]])await db.query('insert into progress(tenant_id,user_id,course_id) values($1,$2,$3)',[id(t),id(u),id(c)]);
await db.query(`insert into document_chunks(tenant_id,course_id,source_name,body) values($1,$2,'manual','security onboarding')`,[id(1),id(301)]);
async function as(n,fn){await db.exec(`set role authenticated;select set_config('request.jwt.claim.sub','${id(n)}',false);`);try{await fn();}finally{await db.exec('reset role');}}
async function count(sql,n){const r=await db.query(sql);assert.equal(r.rows.length,n,sql);checks++;}
async function denied(sql){await assert.rejects(()=>db.exec(sql));checks++;}
await as(102,async()=>{
 await count('select * from tenants',1);await count('select * from users',1);await count('select * from courses',1);await count('select * from progress',1);
 await count(`select * from courses where tenant_id='${id(2)}'`,0);
 await denied(`update users set role='HR' where id='${id(102)}'`);
 await denied(`update progress set passed=true`);
 await denied(`insert into agent_logs(actor_id,agent,model,prompt_version) values('${id(102)}','tutor','test','1')`);
 await denied(`select product_metrics()`);
 await denied(`select begin_agent_run('${id(102)}','tutor','test')`);
 await denied(`select apply_assessment('${id(102)}','${id(301)}',100,'ok','{}')`);
 await count(`select * from search_chunks('${id(301)}','security')`,1);
 await count(`select * from search_chunks('${id(302)}','security')`,0);
});
await as(103,async()=>{await count('select * from progress',1);await count('select * from users',2);});
await as(101,async()=>{
 await count('select * from progress',2);await count('select * from users',4);
 await denied(`insert into courses(tenant_id,title,grade,created_by) values('${id(2)}','Evil','Junior','${id(201)}')`);
 await denied(`insert into courses(tenant_id,title,grade,created_by) values('${id(1)}','Evil','Junior','${id(201)}')`);
 await denied(`delete from agent_logs`);
});
await as(999,async()=>{await count('select * from courses',0);await count('select * from progress',0);await count('select product_metrics()',1);});
await denied(`insert into progress(tenant_id,user_id,course_id) values('${id(1)}','${id(102)}','${id(302)}')`);
await db.exec('set role service_role');
const run=await db.query(`select begin_agent_run('${id(102)}','tutor','test') as id`);assert.ok(run.rows[0].id);checks++;
await denied(`select begin_agent_run('${id(102)}','tutor','test')`);
await denied(`select begin_agent_run('${id(102)}','methodist','test')`);
const result=await db.query(`select apply_assessment('${id(102)}','${id(301)}',80,'Good','{"pass_score":70,"criteria":[{"criterion":"Accuracy","max_score":100}]}') as result`);
assert.equal(result.rows[0].result.passed,true);checks++;
await denied(`select apply_assessment('${id(102)}','${id(302)}',100,'Bad','{}')`);
await denied(`select apply_assessment('${id(102)}','${id(301)}',100,'Bad','{}')`);
await db.exec('reset role');
await as(101,async()=>{
 const source=await db.query(`select id from document_chunks where course_id='${id(301)}'`);
 const draft=await db.query('select save_generated_course($1,$2,$3) as result',[id(301),'New draft',{sourceIds:[source.rows[0].id]}]);
 const created=draft.rows[0].result;
 assert.equal(created.status,'draft');checks++;
 assert.notEqual(created.content.sourceIds[0],source.rows[0].id);checks++;
 await count(`select * from document_chunks where course_id='${created.courseId}'`,1);
 await denied(`select save_generated_course('${id(302)}','Denied','{}')`);
});
await as(102,async()=>{await denied(`select save_generated_course('${id(301)}','Denied','{}')`);});
await db.query('update tenants set active=false where id=$1',[id(1)]);
await as(102,async()=>{await count('select * from users',0);await count('select * from courses',0);await count('select * from progress',0);});
console.log(`PASS: migration + ${checks} PostgreSQL isolation, RBAC, quota and assessment assertions`);
await db.close();
