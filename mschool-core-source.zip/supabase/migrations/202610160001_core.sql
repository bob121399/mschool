begin;
create type public.app_role as enum ('SuperAdmin','HR','Manager','Employee');
create type public.grade as enum ('Junior','Middle','Senior','Head of Department');
create type public.agent_key as enum ('sales','support','product_analyst','methodist','tutor','assessor','hr_analyst');
create table public.tenants(id uuid primary key default gen_random_uuid(), name text not null check(length(name) between 1 and 200), active boolean not null default true, created_at timestamptz not null default now());
create table public.departments(id uuid primary key default gen_random_uuid(),tenant_id uuid not null references public.tenants(id),name text not null,unique(tenant_id,id));
create table public.users(id uuid primary key references auth.users(id),tenant_id uuid references public.tenants(id),role public.app_role not null,department_id uuid,display_name text not null,active boolean not null default true,created_at timestamptz not null default now(),unique(tenant_id,id),foreign key(tenant_id,department_id) references public.departments(tenant_id,id),check ((role='SuperAdmin' and tenant_id is null and department_id is null) or (role<>'SuperAdmin' and tenant_id is not null)),check(role not in ('Manager','Employee') or department_id is not null));
create table public.agents(key public.agent_key primary key,scope text not null check(scope in ('platform','tenant')),allowed_roles public.app_role[] not null,enabled boolean not null default true,prompt_version text not null default '1.0.0');
insert into public.agents(key,scope,allowed_roles) values ('sales','platform','{SuperAdmin}'),('support','platform','{SuperAdmin,HR,Manager,Employee}'),('product_analyst','platform','{SuperAdmin}'),('methodist','tenant','{HR}'),('tutor','tenant','{HR,Manager,Employee}'),('assessor','tenant','{Employee}'),('hr_analyst','tenant','{HR,Manager}');
create table public.courses(id uuid primary key default gen_random_uuid(),tenant_id uuid not null references public.tenants(id),title text not null,grade public.grade not null,status text not null default 'draft' check(status in ('draft','published','archived')),content jsonb not null default '{}'::jsonb,rubric jsonb not null default '{}'::jsonb,created_by uuid not null,created_at timestamptz not null default now(),unique(tenant_id,id),foreign key(tenant_id,created_by) references public.users(tenant_id,id));
create table public.progress(id uuid primary key default gen_random_uuid(),tenant_id uuid not null,course_id uuid not null,user_id uuid not null,completion numeric(5,2) not null default 0 check(completion between 0 and 100),passed boolean not null default false,score numeric(5,2) check(score between 0 and 100),feedback text,eligible_next_grade public.grade,updated_at timestamptz not null default now(),unique(tenant_id,course_id,user_id),foreign key(tenant_id,course_id) references public.courses(tenant_id,id),foreign key(tenant_id,user_id) references public.users(tenant_id,id));
-- Source ingestion is a separate vertical slice; only trusted HR content enters retrieval.
create table public.document_chunks(id uuid primary key default gen_random_uuid(),tenant_id uuid not null,course_id uuid not null,source_name text not null,body text not null check(length(body) between 1 and 12000),search tsvector generated always as (to_tsvector('simple',body)) stored,foreign key(tenant_id,course_id) references public.courses(tenant_id,id));
create index chunks_search on public.document_chunks using gin(search);
create table public.agent_logs(id uuid primary key default gen_random_uuid(),tenant_id uuid references public.tenants(id),actor_id uuid not null references public.users(id),agent public.agent_key not null references public.agents(key),status text not null default 'running' check(status in ('running','succeeded','failed')),prompt_version text not null,model text not null,output_tokens integer,error_code text,created_at timestamptz not null default now(),finished_at timestamptz);
create index agent_logs_quota on public.agent_logs(actor_id,created_at);
create index users_tenant on public.users(tenant_id,department_id);
create index courses_tenant on public.courses(tenant_id);
create index progress_user on public.progress(tenant_id,user_id);
create index chunks_course on public.document_chunks(tenant_id,course_id);
create index logs_tenant on public.agent_logs(tenant_id,created_at);
create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;
-- SECURITY DEFINER avoids recursive users policies. Never trust editable JWT metadata.
create function private.current_actor() returns public.users language sql stable security definer set search_path='' as $$ select u from public.users u left join public.tenants t on t.id=u.tenant_id where u.id=auth.uid() and u.active and (u.role='SuperAdmin' or t.active) $$;
revoke all on function private.current_actor() from public;
grant execute on function private.current_actor() to authenticated;
create function private.can_see_user(target uuid,tenant uuid) returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.users u where u.id=target and u.tenant_id=tenant and tenant=(private.current_actor()).tenant_id and ((private.current_actor()).role='HR' or u.id=auth.uid() or ((private.current_actor()).role='Manager' and u.department_id=(private.current_actor()).department_id))) $$;
revoke all on function private.can_see_user(uuid,uuid) from public;
grant execute on function private.can_see_user(uuid,uuid) to authenticated;
alter table public.tenants enable row level security;
alter table public.departments enable row level security;
alter table public.users enable row level security;
alter table public.agents enable row level security;
alter table public.courses enable row level security;
alter table public.progress enable row level security;
alter table public.document_chunks enable row level security;
alter table public.agent_logs enable row level security;
revoke all on public.tenants,public.departments,public.users,public.agents,public.courses,public.progress,public.document_chunks,public.agent_logs from anon,authenticated;
grant select on public.tenants,public.departments,public.users,public.agents,public.courses,public.progress,public.document_chunks,public.agent_logs to authenticated;
grant insert,update,delete on public.courses,public.document_chunks to authenticated;
create policy tenants_read on public.tenants for select to authenticated using(id=(private.current_actor()).tenant_id or (private.current_actor()).role='SuperAdmin');
create policy departments_read on public.departments for select to authenticated using(tenant_id=(private.current_actor()).tenant_id);
create policy users_read on public.users for select to authenticated using(id=(private.current_actor()).id or private.can_see_user(id,tenant_id));
create policy agents_read on public.agents for select to authenticated using(enabled and (private.current_actor()).role=any(allowed_roles));
create policy courses_read on public.courses for select to authenticated using(tenant_id=(private.current_actor()).tenant_id and ((private.current_actor()).role='HR' or (status='published' and exists(select 1 from public.progress p where p.course_id=courses.id and p.user_id=auth.uid()))));
create policy courses_write on public.courses for all to authenticated using(tenant_id=(private.current_actor()).tenant_id and (private.current_actor()).role='HR') with check(tenant_id=(private.current_actor()).tenant_id and (private.current_actor()).role='HR');
create policy progress_read on public.progress for select to authenticated using(private.can_see_user(user_id,tenant_id));
create policy chunks_read on public.document_chunks for select to authenticated using(tenant_id=(private.current_actor()).tenant_id and exists(select 1 from public.courses c where c.id=course_id));
create policy chunks_write on public.document_chunks for all to authenticated using(tenant_id=(private.current_actor()).tenant_id and (private.current_actor()).role='HR') with check(tenant_id=(private.current_actor()).tenant_id and (private.current_actor()).role='HR');
create policy logs_read on public.agent_logs for select to authenticated using((actor_id=(private.current_actor()).id) or (tenant_id=(private.current_actor()).tenant_id and (private.current_actor()).role='HR') or (tenant_id is null and (private.current_actor()).role='SuperAdmin'));
-- No browser writes to roles, tenants, audit, grades or assessment results.
create function public.search_chunks(p_course uuid,p_query text) returns table(id uuid,source_name text,body text) language sql stable security invoker set search_path='' as $$ select c.id,c.source_name,c.body from public.document_chunks c where c.course_id=p_course and c.search @@ plainto_tsquery('simple',left(p_query,1000)) order by ts_rank(c.search,plainto_tsquery('simple',left(p_query,1000))) desc limit 6 $$;
create function public.product_metrics() returns jsonb language plpgsql stable security definer set search_path='' as $$ begin
if (private.current_actor()).role is distinct from 'SuperAdmin' then raise exception 'Forbidden' using errcode='42501'; end if;
return (select coalesce(jsonb_agg(x),'[]'::jsonb) from (select c.grade,count(*) as enrollments,round(avg(p.completion),2) as average_completion,round(100.0*count(*) filter(where p.passed)/count(*),2) as pass_rate from public.progress p join public.courses c on c.id=p.course_id group by c.grade having count(distinct p.tenant_id)>=3 and count(*)>=10) x); end $$;
-- Distributed quota lock closes parallel-request races before any model spend.
create function public.begin_agent_run(p_actor uuid,p_agent public.agent_key,p_model text) returns uuid language plpgsql security definer set search_path='' as $$ declare u public.users; a public.agents; run_id uuid; begin
perform pg_advisory_xact_lock(hashtextextended(p_actor::text,0));
select * into u from public.users where id=p_actor and active;
select * into a from public.agents where key=p_agent and enabled;
if u.id is null or a.key is null or not(u.role=any(a.allowed_roles)) or (u.tenant_id is not null and not exists(select 1 from public.tenants where id=u.tenant_id and active)) then raise exception 'Forbidden' using errcode='42501'; end if;
if (select count(*) from public.agent_logs where actor_id=p_actor and created_at>now()-interval '1 minute')>=10 or exists(select 1 from public.agent_logs where actor_id=p_actor and status='running' and created_at>now()-interval '2 minutes') then raise exception 'Rate limited' using errcode='P0001'; end if;
insert into public.agent_logs(tenant_id,actor_id,agent,prompt_version,model) values(u.tenant_id,u.id,a.key,a.prompt_version,p_model) returning id into run_id; return run_id; end $$;
create function public.apply_assessment(p_actor uuid,p_course uuid,p_score numeric,p_feedback text,p_rubric jsonb) returns jsonb language plpgsql security definer set search_path='' as $$ declare c public.courses; u public.users; threshold numeric; result boolean; begin
select * into u from public.users where id=p_actor and active and role='Employee';
select * into c from public.courses where id=p_course and tenant_id=u.tenant_id and status='published' for share;
if c.id is null or not exists(select 1 from public.tenants where id=u.tenant_id and active) or p_score not between 0 and 100 then raise exception 'Forbidden' using errcode='42501'; end if;
if c.rubric is distinct from p_rubric then raise exception 'Rubric changed; retry'; end if;
threshold=(c.rubric->>'pass_score')::numeric;
if threshold is null or threshold not between 0 and 100 then raise exception 'Invalid rubric'; end if;
result=p_score>=threshold;
update public.progress set score=p_score,passed=result,feedback=p_feedback,completion=case when result then 100 else completion end,eligible_next_grade=case when result then case c.grade when 'Junior' then 'Middle'::public.grade when 'Middle' then 'Senior'::public.grade when 'Senior' then 'Head of Department'::public.grade else null end else null end,updated_at=now() where tenant_id=u.tenant_id and course_id=c.id and user_id=u.id;
if not found then raise exception 'Not enrolled' using errcode='42501'; end if;
return jsonb_build_object('passed',result,'score',p_score,'feedback',p_feedback); end $$;
revoke all on function public.search_chunks(uuid,text),public.product_metrics(),public.begin_agent_run(uuid,public.agent_key,text),public.apply_assessment(uuid,uuid,numeric,text,jsonb) from public,anon,authenticated;
grant execute on function public.search_chunks(uuid,text),public.product_metrics() to authenticated;
grant execute on function public.begin_agent_run(uuid,public.agent_key,text),public.apply_assessment(uuid,uuid,numeric,text,jsonb) to service_role;
-- Atomic draft + source copy: no orphaned course and no source IDs crossing course boundaries.
create function public.save_generated_course(p_source uuid,p_title text,p_content jsonb) returns jsonb language plpgsql security invoker set search_path='' as $$
declare c public.courses; chunk public.document_chunks; new_course uuid; new_chunk uuid; copied_content text:=p_content::text;
begin
if (private.current_actor()).role is distinct from 'HR' then raise exception 'Forbidden' using errcode='42501'; end if;
select * into c from public.courses where id=p_source and tenant_id=(private.current_actor()).tenant_id for share;
if c.id is null then raise exception 'Source not found' using errcode='42501'; end if;
insert into public.courses(tenant_id,title,grade,created_by,content) values(c.tenant_id,p_title,c.grade,auth.uid(),p_content) returning id into new_course;
for chunk in select * from public.document_chunks where course_id=c.id and tenant_id=c.tenant_id loop
 new_chunk:=gen_random_uuid();
 insert into public.document_chunks(id,tenant_id,course_id,source_name,body) values(new_chunk,c.tenant_id,new_course,chunk.source_name,chunk.body);
 copied_content:=replace(copied_content,chunk.id::text,new_chunk::text);
end loop;
update public.courses set content=copied_content::jsonb where id=new_course;
return jsonb_build_object('courseId',new_course,'status','draft','content',copied_content::jsonb);
end $$;
revoke all on function public.save_generated_course(uuid,text,jsonb) from public,anon;
grant execute on function public.save_generated_course(uuid,text,jsonb) to authenticated;
grant select,update on public.agent_logs to service_role;
commit;
